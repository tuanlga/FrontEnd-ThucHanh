
<table border="0" cellpadding="1" cellspacing="1" style="width: 500px; ">
	<tbody>
		<tr>
			<td>Họ tên</td>
		<td><input name="HoTen" type="text" />
			<?php echo $HoTen;?>
		</td>
		</tr>
		<tr>
			<td>Giới tính</td>
			<td>
			<?php
				if ($GioiTinh == 1){
					echo "<input checked='checked' name='GioiTinh' type='radio' value='1' />Nam";
					echo "<input name='GioiTinh' type='radio' value='0' />Nữ";
				}
				else {
					echo "<input name='GioiTinh' type='radio' value='1' />Nam";
					echo "<input checked='checked' name='GioiTinh' type='radio' value='0' />Nữ";
				}
			?>
			</td>
		</tr>
		<tr>
			<td>Tuổi</td>
			<td><input name="Tuoi" type="text" /></td>
		</tr>
		<tr>
			<td>Quốc gia</td>
			<td>
				<select name="QuocGia">
				<?php
					switch ($QuocGia){
						case 'VN':
							echo "<option selected='selected' value='VN'>Việt Nam</option>";
							echo "<option value='US'>Mỹ</option>";
							echo "<option value='JP'>Nhật</option>";
							break;
						case 'US':
							echo "<option value='VN'>Việt Nam</option>";
							echo "<option selected='selected' value='US'>Mỹ</option>";
							echo "<option value='JP'>Nhật</option>";
							break;	
						case 'JP':
							echo "<option value='VN'>Việt Nam</option>";
							echo "<option value='US'>Mỹ</option>";
							echo "<option selected='selected' value='JP'>Nhật</option>";
							break;	
					}						
				?>
				</select>
			</td>
		</tr>
		<tr>
			<td>Địa chỉ</td>
			<td>
				<textarea cols="50" name="DiaChi" rows="5">
					<?php
						echo nl2br($DiaChi, false);
					?>
				</textarea>
			</td>
		</tr>
	</tbody>
</table>

